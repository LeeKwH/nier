# javascript ==> interpolation

import sys,argparse,json, pandas as pd


sys.path.append('./')
savepath ='D:\\cyj\\00_project\\02_algaeAI\\2023\\00_dev\\nier\\backend\\.user\\' 

parser = argparse.ArgumentParser(description='Arguments transported from JS to Py')
#parser.add_argument('col_mth_j',type = str)
parser.add_argument('columns_j',type = str)
parser.add_argument('method',type = str)
parser.add_argument('User_Name',type = str,default='user_1')
args  = parser.parse_args()
col = json.loads(args.columns_j)
df = pd.DataFrame.from_dict(col)
#col_mth = json.loads(col_mth_j)
#col_mth_sample = [['linear','1,2,3'],['any','6,7,8']]

#df = pd.read_csv(str('./LocalDB/')+args.User_Name+str('/data/rawdata.csv'),parse_dates='date', encoding='cp949', index_col=0)
#df = pd.read_csv((savepath,str(args.User_Name)+'\\.preprocessing\\management.csv'),parse_dates='date', encoding='cp949', index_col=0)


def Interpolate1D():
    return df.interpolate(method=args.method)

def DropNA():
    return df.dropna(how=args.method)

def RemoveNoise():
    return self.df

if args.method in ['linear', 'time', 'index', 'values','nearest', 'zero', 'slinear', 'quadratic', 'cubic',  'krogh', 'pchip', 'akima', 'cubicspline']:
    df2=Interpolate1D()

elif args.method in ['any', 'all']:
    df2=DropNA()

elif args.method in ['outlier','binning','regression','clustering']:
    df2=RemoveNoise()

else:
    print('invalid method')

# df2.index.astype(str, copy = False)
print(json.dumps(df2.to_dict('records'), ensure_ascii=False ,separators=(',', ':')))
# print(df2.to_dict('index'))
#df2.to_csv(os.path.join(savepath,str(args.User_Name)+'\\.preprocessing\\processed.csv'), encoding='cp949')