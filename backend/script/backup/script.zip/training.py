import argparse, sys, os, torch
import random, matplotlib.pyplot as plt
from torch.autograd import Variable 
sys.path.append('./')


parser = argparse.ArgumentParser()
parser.add_argument('user_name', type=str)
parser.add_argument('model_name', type=str)
#parser.add_argument('input_dir', type=str)
parser.add_argument('input_info', type=str) #[[100,12,9],[100,12,9],[100,12,9],...]
parser.add_argument('learn_config', type=str) #learn_config = {'epoch':100,'learn_rate':0.01,'device':'cuda','optim':'torch.optim.RMSprop','loss_f':'torch.nn.MSELoss()'}
parser.add_argument('fig_size', type=str) #(10,4)


args = parser.parse_args()
dir_script = nowpath+'/.user/'+args.user_name+'/.model/'+args.model_name+'/'
dir_train_x = nowpath+'/.user/'+args.user_name+'/input/'+args.model_name+'/train/'
dir_val = nowpath+'/.user/'+args.user_name+'/input/'+args.model_name+'/val/'
dir_model_save = nowpath+'/.user/'+args.user_name+'/model/'+args.model_name+'/weight/'+args.model_name
dir_loss = nowpath+'/.user/'+args.user_name+'/model/'+args.model_name+'/loss/'+args.model_name


device = torch.device(args.learn_config['device'])


#train_y = pd.read_csv(dir_val + '/train_y.csv', encoding='cp949',index_col=0)
#val_y = pd.read_csv(dir_val + '/val_y.csv', encoding='cp949',index_col=0)

#Generate dummy inputs from the input info
list_inps = []
for inp in input_info:
    list_inps.append(torch.rand(inp))

train_y = torch.rand(list_inps[0].size(0),1)
val_y = torch.rand(list_inps[0].size(0),1)

#Import the model from the script
f = open(dir_script+'.py',encoding='UTF8')
exec(f.read())
f.close()
exec(args.model_name+'_init ='+args.model_name+'(list_inps)')
exec(args.model_name+'_init.to(device)')

#Generate dummy inputs from the input info
list_inps = []
for inp in input_info:
    list_inps.append(torch.rand(inp))
val_list_inps = list_inps

exec('optimizer = %s(%s_init.parameters(),lr = %d)'%(args.learn_config['optim'],args.model_name,args.learn_config['learn_rate']))
best_val_loss = 1



#Train
train_losses = []
validation_losses = []
with open(dir_script+log.txt", "w") as f:
    for epoch in range(args.learn_config['epoch']):
        exec('output = '+args.model_name+'_init(list_inps)')#forward pass and update output conv1d_d_input.float().to(device)
        optimizer.zero_grad() #clear the existing gradients though, else gradients will be accumulated to existing gradients.
        exec('loss = %s(output.to(device),train_y.to(device))'%learn_config['loss_f']) # calculate updated loss
        loss.backward() #To backpropagate the error
        optimizer.step() #update the model paramters, i.e backward
        train_losses.append(loss.item())
        ### validation data 
        exec('output_val = '+args.model_name+'_init(val_list_inps)')
        exec('val_loss = %s(output_val.to(device), val_y.to(device))'%learn_config['loss_f'])
        validation_losses.append(val_loss.item())
        #validation loss
        if val_loss.item() < best_val_loss:      
            torch.save(MODEL.state_dict(), open('./.pth', 'wb'))
            f.write('best model save - Epoch: %d, train_loss: %1.5f, val_loss: %1.5f'%(epoch, loss.item(), val_loss.item()))      
            best_val_loss = val_loss.item()
        if epoch % 1 == 0:
            f.write('Epoch: %d, train_loss: %1.5f, val_loss: %1.5f' % (epoch, loss.item(), val_loss.item()))
    f.write('Training completed')



#Plot the loss curve
fig = plt.figure(figsize=args.fig_size)
plt.plot(train_losses, label='Training Loss')
plt.plot(validation_losses, label='Validation Loss')
minposs = validation_losses.index(min(validation_losses))+1
plt.axvline(minposs, linestyle='--', color='r',label='val_loss_minima')
plt.xlabel('epochs')
plt.ylabel('loss')
plt.grid(True)
plt.legend(loc='upper right')
plt.tight_layout()
plt.show()
if os.path.isfile(dir_loss+'.png'):
    os.remove(dir_loss+'.png')
plt.savefig(dir_loss+'.png', dpi=400)




